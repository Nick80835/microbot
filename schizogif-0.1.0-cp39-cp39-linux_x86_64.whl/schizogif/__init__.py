from .schizogif import generate_gif

__all__ = [
    "generate_gif"
]